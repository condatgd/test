package de.berlin.gd.calculator.domain.alu;

public interface ALU {

    int evaluate(String expr);

}
