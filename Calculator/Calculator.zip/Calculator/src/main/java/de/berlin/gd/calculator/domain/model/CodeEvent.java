package de.berlin.gd.calculator.domain.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CodeEvent {
    private Code code;
}
