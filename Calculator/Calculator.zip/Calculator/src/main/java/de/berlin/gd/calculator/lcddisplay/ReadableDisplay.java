package de.berlin.gd.calculator.lcddisplay;

public interface ReadableDisplay {
    String read();
}
